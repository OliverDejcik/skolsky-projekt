// sachy.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;

int main() {
    int a;
    int b;
    bool �achy[8][8] = {
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
    };
    cout << "zadaj poziciu figurky (riadok) 1-8" << endl;
    cin >> a ;
    cout << "zadaj poziciu figurky (stlpec 1-8" << endl;
    cin  >> b ;
    b = b - 1;
    a = a - 1;
    if (a < 8) {
        if (b < 8) {
            �achy[a][b] = 1;
        }

    }
    else cout << "nauc sa citat" << endl;
    for (int i = 0; i < 8; i++) {
        for (int o = 0; o < 8; o++) {
            cout << �achy [i][o] ;
        }
        cout << endl;
    }
    std::cout << "Hello World!\n";
}